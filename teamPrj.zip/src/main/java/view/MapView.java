package view;

import javax.swing.*;

public class MapView extends JFrame {

    private GoogleAPI googleAPI = new GoogleAPI();
    private String location = "이대역";
    private JLabel googleMap;
    public MapView(){
        googleAPI.downloadMap(location);
        googleMap = new JLabel(googleAPI.getMap(location));
        googleAPI.fileDelete(location);
        add(googleMap);

        setTitle("Google Maps");
        setVisible(true);
        pack();;
    }


}
