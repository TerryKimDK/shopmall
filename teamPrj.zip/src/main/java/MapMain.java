import view.MapView;

import java.util.Map;

public class MapMain {
    public static void main(String[] args) {
        new MapView();
    }
}
